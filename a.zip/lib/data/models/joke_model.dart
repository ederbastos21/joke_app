import 'package:json_annotation/json_annotation.dart';

part 'joke_model.g.dart';

@JsonSerializable()
class JokeModel {
  final int id;
  final String category;
  final String type;

  // Piadas de dois atos têm setup + delivery
  final String? setup;
  final String? delivery;

  // Piadas de um ato têm apenas joke
  final String? joke;

  final bool safe;

  JokeModel({
    required this.id,
    required this.category,
    required this.type,
    this.setup,
    this.delivery,
    this.joke,
    required this.safe,
  });

  factory JokeModel.fromJson(Map<String, dynamic> json) =>
      _$JokeModelFromJson(json);

  Map<String, dynamic> toJson() => _$JokeModelToJson(this);

  // Retorna o texto completo da piada para exibição
  String get fullText {
    if (type == 'twopart') {
      return '$setup\n\n$delivery';
    }
    return joke ?? '';
  }
}
