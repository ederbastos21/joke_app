import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers/joke_providers.dart';

// SettingsScreen permite alterar o tema do app.
// A preferência é salva no SharedPreferences e persiste entre sessões.
class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Observa o estado do tema (true = escuro)
    final isDarkMode = ref.watch(themeModeProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Configurações')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            SwitchListTile(
              title: const Text('Modo escuro'),
              value: isDarkMode,
              onChanged: (_) {
                // Altera e salva o tema no SharedPreferences
                ref.read(themeModeProvider.notifier).toggle();
              },
            ),
          ],
        ),
      ),
    );
  }
}
