import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'domain/app_router.dart';
import 'providers/joke_providers.dart';

void main() {
  runApp(
    // ProviderScope é obrigatório para o Riverpod funcionar.
    // Envolve todo o app para que qualquer widget acesse os providers.
    const ProviderScope(
      child: JokesApp(),
    ),
  );
}

class JokesApp extends ConsumerWidget {
  const JokesApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Observa o tema para aplicar em toda a árvore de widgets
    final isDarkMode = ref.watch(themeModeProvider);

    return MaterialApp.router(
      title: 'Piadas App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.light(),
      darkTheme: ThemeData.dark(),
      themeMode: isDarkMode ? ThemeMode.dark : ThemeMode.light,
      // GoRouter cuida de toda a navegação
      routerConfig: appRouter,
    );
  }
}
